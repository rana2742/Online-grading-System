<?php
session_start();
require_once('../Dbconnect.php');

// Store session values in variables
$store1 = $_SESSION['semester'];
$store2 = $_SESSION['roll_no'];
$store3 = $_SESSION['subject'];
$store4 = $_SESSION['student'];

// Check if the semester is 2023-27 and handle form submission
if ($_SESSION['semester'] == '2023-27' && $_SERVER['REQUEST_METHOD'] == 'POST') {
    // Collect form data
    $mid_marks = $_POST['mid_marks'];
    $sessional = $_POST['sessional'];
    $final_marks = $_POST['final_marks'];

    // Calculate total marks
    $total_marks = $mid_marks + $sessional + $final_marks;

    // Sanitize inputs to prevent SQL injection
    $mid_marks = mysqli_real_escape_string($conn, $mid_marks);
    $sessional = mysqli_real_escape_string($conn, $sessional);
    $final_marks = mysqli_real_escape_string($conn, $final_marks);
    $total_marks = mysqli_real_escape_string($conn, $total_marks); // Ensure total marks are sanitized too

     $sql = "UPDATE session23 SET 
                mid_marks='$mid_marks', 
                sessional='$sessional', 
                final_marks='$final_marks', 
                total_marks='$total_marks' 
            WHERE roll_no='$store2' AND name='$store4' AND subject='$store3'";

    // Execute the query
    if (mysqli_query($conn, $sql)) {
        echo "Record updated successfully!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Updating Record</title>
</head>
<link rel="stylesheet" href="updated.css">
<body>
<header>
        <img src="../pics/images (1).jpeg" alt="Computer Engineering">
        <h1>Department of Computer Engineering BZU Multan</h1>
    </header> 
    <h1 style="margin-top: 15%;">Welcome! <?php echo $store4; ?></h1>
    <h2><?php echo "Do you really want to update the record of Roll Number " . $store2 . " in Semester " . $store1 . " for subject " . $store3; ?></h2>
    
    <!-- Form to submit updated data -->
    <form action="updated.php" method="POST">
        <label for="mid_marks">Mid Marks:</label>
        <input type="text" name="mid_marks" placeholder="Enter Mid-term Marks" required><br><br>

        <label for="sessional">Sessional Marks:</label>
        <input type="text" name="sessional" placeholder="Enter Sessional Marks" required><br><br>

        <label for="final_marks">Final Marks:</label>
        <input type="text" name="final_marks" placeholder="Enter Final Exam Marks" required><br><br>

        <input type="submit" value="Update Record">
    </form>
</body>
</html>
