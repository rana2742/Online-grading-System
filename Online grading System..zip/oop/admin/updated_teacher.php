<?php session_start(); require_once('../Dbconnect.php'); $tname = $_SESSION['tname']; $semester = $_SESSION['semester']; $change = $_SESSION['change']; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Teacher Information</title>
    
</head>
<body>
    <header>
        <img src="../pics/images (1).jpeg" alt="Computer Engineering">
        <h1>Department of Computer Engineering BZU Multan</h1>
    </header>

    <?php
    if ($change == 'id') {
        echo '
        <form method="POST">
            <input type="text" name="id" placeholder="Give new id to teacher">
            <input type="submit" name="submit" value="Update">
        </form>
        ';
        if (isset($_POST['submit'])) {
            $new_id = $_POST['id'];
            $sql = "UPDATE assign_subjects SET id='$new_id' WHERE name='$tname' AND semester='$semester'";
            mysqli_query($conn, $sql);
        }
    } elseif ($change == 'subject') {
        echo '
        <form method="POST">
            <input type="text" name="subject" placeholder="change subject name">
            <input type="submit" name="submit" value="Update">
        </form>
        ';
        if (isset($_POST['submit'])) {
            $new_subject = $_POST['subject'];
            $sql = "UPDATE assign_subjects SET subject='$new_subject' WHERE name='$tname' AND semester='$semester'";
            mysqli_query($conn, $sql);
        }
    } elseif ($change == 'coursecode') {
        echo '
        <form method="POST">
            <input type="text" name="coursecode" placeholder="Change Course Code">
            <input type="submit" name="submit" value="Update">
        </form>
        ';
        if (isset($_POST['submit'])) {
            $new_coursecode = $_POST['coursecode'];
            $sql = "UPDATE assign_subjects SET coursecode='$new_coursecode' WHERE name='$tname' AND semester='$semester'";
            mysqli_query($conn, $sql);
        }
    }
    ?>
</body>
</html>

<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 20px;
            text-align: center;
        }

        header img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin: 20px;
        }

        form {
            width: 50%;
            margin: 40px auto;
            padding: 20px;
            background-color: #fff;
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        input[type="text"] {
            width: 100%;
            height: 40px;
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ccc;
        }

        input[type="submit"] {
            width: 100%;
            height: 40px;
            background-color: #333;
            color: #fff;
            padding: 10px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #555;
        }
    </style>