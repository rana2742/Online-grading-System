<?php
session_start();
echo "<div style='text-align: center; font-size: 24px; color: #4CAF50; font-family: Arial, sans-serif; padding: 20px; background-color: #f0f8ff; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);'>";
echo "Welcome, <span style='font-weight: bold; color: #2c3e50;'>" . htmlspecialchars($_SESSION['tname']) . "</span>!";
echo "</div>";

require_once '../Dbconnect.php'; // Include your database connection

// Hardcoded session table name
$session_table = 'session21';

// Handle form submission for adding marks
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $roll_no = $_POST['roll_no'];
    $name = $_POST['name'];
    $mid_marks = $_POST['mid_marks'];
    $sessional = $_POST['sessional'];
    $final_marks = $_POST['final_marks'];
    
    $sub = $_SESSION['subject']; // Get subject from session

    // Calculate total marks
    $total_marks = $mid_marks + $sessional + $final_marks;

    $time = date('Y-m-d H:i:s'); // Get the current timestamp

    // Insert data into the specific session table
    $insert_query = "INSERT INTO $session_table (roll_no, name, subject, mid_marks, sessional, final_marks, total_marks, time) 
                     VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare the SQL statement
    $stmt = $conn->prepare($insert_query);
    
    // Check if the preparation was successful
    if ($stmt === false) {
        die('Prepare failed: ' . htmlspecialchars($conn->error));
    }

    // Bind parameters
    // Corrected to match the number of placeholders (8 placeholders and 8 variables)
    $stmt->bind_param("issiiiss", $roll_no, $name, $sub, $mid_marks, $sessional, $final_marks, $total_marks, $time);

    // Execute the query
    if ($stmt->execute()) {
        echo "<p style='color: green;'>Marks successfully added to $session_table!</p>";
    } else {
        echo "<p style='color: red;'>Error adding marks: " . $stmt->error . "</p>";
    }
}

// Fetch data from the session table
$sql = "SELECT * FROM $session_table";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard</title>
    <link rel="stylesheet" href="sv.css">
</head>
<body>
    <h3>Teacher Dashboard - Add Marks</h3>
    <button><a href="teacher.php" style="color: white; text-decoration:none;">Home</a></button>
    <button style="margin-left: 20px;"><a href="../Index.php" style="color: white; text-decoration:none;">Log Out</a></button>
    <form method="POST" action=""onsubmit="validateMarks(event)" >
        <label for="roll_no">Roll No:</label>
        <input type="number" id="roll_no" name="roll_no" required placeholder="Enter Roll Number">

        <label for="name">Student Name:</label>
        <input type="text" id="name" name="name" required placeholder="Enter Student Name">
        <label for="mid_marks">Mid Marks:</label>
        <input type="number" id="mid_marks" name="mid_marks" required placeholder="Enter Mid Marks">

        <label for="sessional">Sessional Marks:</label>
        <input type="number" id="sessional" name="sessional" required placeholder="Enter Sessional Marks">

        <label for="final_marks">Final Marks:</label>
        <input type="number" id="final_marks" name="final_marks" required placeholder="Enter Final Marks">

        <button type="submit">Add Marks</button>
    </form>

    <h3>Marks List</h3>
    <table>
        <thead>
            <tr>
                <th>Roll No</th>
                <th>Name</th>
                <th>Subject</th>
                <th>Mid Marks</th>
                <th>Sessional Marks</th>
                <th>Final Marks</th>
                <th>Total Marks</th>
                <th>Time</th>
            </tr>
        </thead>
        <tbody>
            <?php
            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['roll_no']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['subject']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['mid_marks']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['sessional']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['final_marks']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['total_marks']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['time']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7'>No marks added yet.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</body>
</html>
<script>
        function validateMarks(event) {
            // Get input values
            const midMarks = document.getElementById("mid_marks").value;
            const sessionalMarks = document.getElementById("sessional").value;
            const finalMarks = document.getElementById("final_marks").value;

            // Validate marks
            if (midMarks > 30) {
                alert("Mid marks should be less than or equal to 30.");
                event.preventDefault(); // Prevent form submission
                return false;
            }
            if (sessionalMarks > 20) {
                alert("Sessional marks should be less than or equal to 20.");
                event.preventDefault(); // Prevent form submission
                return false;
            }
            if (finalMarks > 50) {
                alert("Final marks should be less than or equal to 50.");
                event.preventDefault(); // Prevent form submission
                return false;
            }
        }
    </script>