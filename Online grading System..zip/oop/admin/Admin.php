<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin portal</title>
    <link rel="stylesheet" href="admin.css">
  </head>
   
  <body>
    <div class="containeer">
    <nav>
        <div class="left">Department of Computer Engineering</div>
        <div class="sideicons">
          <ul>
             <li><a href="assign.php">Assign Subjects</a> </li>
             <li><a href="upteacher.php">Update Teacher Record</a></li>
             <li><a href="allocated.php">Subject Allocation Status</a> </li>
             <li><a href="update.php"> Update student record</a></li>
            <li><a href="mycv.html"></a></li>
            <button onclick="window.location.href='../Index.php';">Log Out</button>
         
          </ul>
        </div>
    </nav>
<h1 style="text-align: center;padding-top: 70px; ">Welcome to the Admin Portal!</h1>
<h1>Key features:</h1>
<p>Our website offers a range of key features designed to enhance user experience and streamline management tasks. Admins can easily search, update, and delete student records, with options to modify personal details, enrollment status, and academic performance.</p>
 <h1>Objectives:</h1>
<p>  The admin portal is designed to provide a centralized and secure platform for managing users, content, and system settings efficiently. It enables admins to easily add, update, and delete records, control user permissions with role-based access, and monitor system health in real-time</p>
  
<footer>
    Department of computer Engineering BZU Multan®|©All rights reserved
  </footer>
</div>
 

  </body>
</html>



