 
<?php
session_start();
require_once('Dbconnect.php');

$subject = $_SESSION['subject'];
$semester = $_SESSION['semester'];
$student = $_SESSION['student'];
$roll_no = $_SESSION['roll_no'];

// Determine the database table based on the semester
$tableName = '';
switch ($semester) {
    case "2023-27":
        $tableName = 'session23';
        break;
    case "2022-26":
        $tableName = 'session22';
        break;
    case "2021-25":
        $tableName = 'session21';
        break;
    case "2024-28":
        $tableName = 'session24';
        break;
    default:
    echo '<span style="background-color: #ffffcc; color: red; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-weight: bold; display: block; margin: 0 auto; text-align: center;">Please Enter correct Semester!<br> The correct format is e.g 2023-27.</span>';

        exit;
}

// Query the database
$sql = "SELECT * FROM $tableName WHERE LOWER(subject) = LOWER('$subject') AND LOWER(name) = LOWER('$student') AND LOWER(roll_no) = LOWER('$roll_no')";
$result = mysqli_query($conn, $sql);

if (!$result) {
    echo "Error in query: " . mysqli_error($conn);
} elseif (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    ?>
    <div class="container">
        <div class="header">
            <h2>Student Result</h2>
        </div>
        <div class="data">
            <label>Subject:</label>
            <span><?php echo $row['subject']; ?></span>
            <br><br>
            <label>Name:</label>
            <span><?php echo $row['name']; ?></span>
            <br><br>
            <label>Roll No.:</label>
            <span><?php echo $row['roll_no']; ?></span>
            <br><br>
            <label>Mid Term Marks:</label>
            <span><?php echo $row['mid_marks']; ?></span>
            <br><br>
            <label>Sessional Marks:</label>
            <span><?php echo $row['sessional']; ?></span>
            <br><br>
            <label>Final Term Marks:</label>
            <span><?php echo $row['final_marks']; ?></span>
            <br><br>
            <label>Total Marks:</label>
            <span><?php echo $row['total_marks']; ?></span>
        </div>
    </div>
  
<button 
    style="width: 70px; height: 40px; border-radius: 5px; background-color: darkcyan; margin-left: 20px; border: none; cursor: pointer; transition: background-color 0.3s, transform 0.2s;" 
    onmouseover="this.style.backgroundColor='teal'; this.style.transform='scale(1.05)';" 
    onmouseout="this.style.backgroundColor='darkcyan'; this.style.transform='scale(1)';">
    <a href="index.php" style="color: white; text-decoration: none; font-size: 14px; font-weight: bold; display: inline-block; width: 100%; height: 100%; line-height: 40px; text-align: center;">
       Home
    </a>
    <?php
} else {
    echo '<span style="background-color: #ffffcc; color: red; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-weight: bold; display: block; margin: 0 auto; text-align: center;"> The data you entered does not match in our System!<br>Please contact us for further Details.</span>';
   
 }

mysqli_close($conn);
?>
<style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
        }
        
        .container {
            width: 80%;
            margin: 40px auto;
            background-color: #fff;
            padding: 20px;
            border: 1px solid #ddd;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        
        .header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }
        
        .data {
            padding: 20px;
        }
        
        .data label {
            display: block;
            margin-bottom: 10px;
        }
        
        .data span {
            font-weight: bold;
        }
    </style>