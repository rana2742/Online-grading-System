<?php session_start(); require_once('../Dbconnect.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Your Result</title>
    <link rel="stylesheet" href="../result.css">
</head>
<body>
    <header>
        <img src="/oop/pics/images (1).jpeg" alt="Computer Engineering">
        <h1>Department of Computer Engineering BZU Multan</h1>
    </header>
    <form method="POST">
        <input type="text" placeholder="Enter Teacher name" name="tname" required><br><br>
        <input type="text" placeholder="Enter semester" name="semester" required><br><br>
        <div class="radio-group">
            <input type="radio" name="change" id="id" value="id">
            <label for="id">Change ID</label>
            <input type="radio" name="change" id="subject" value="subject">
            <label for="subject">Change Course</label>
            <input type="radio" name="change" id="coursecode" value="coursecode">
            <label for="coursecode">Change Course Code</label>
        </div>
        <input type="submit" id="submitBtn" value="Search">
    </form>
    <button 
    style="width: 70px; height: 40px; border-radius: 5px; background-color: darkcyan; margin-left: 20px; border: none; cursor: pointer; transition: background-color 0.3s, transform 0.2s;" 
    onmouseover="this.style.backgroundColor='teal'; this.style.transform='scale(1.05)';" 
    onmouseout="this.style.backgroundColor='darkcyan'; this.style.transform='scale(1)';">
    <a href="../Index.php" style="color: white; text-decoration: none; font-size: 14px; font-weight: bold; display: inline-block; width: 100%; height: 100%; line-height: 40px; text-align: center;">
        Log Out
    </a>
</button>
<button 
    style="width: 70px; height: 40px; border-radius: 5px; background-color: darkcyan; margin-left: 20px; border: none; cursor: pointer; transition: background-color 0.3s, transform 0.2s;" 
    onmouseover="this.style.backgroundColor='teal'; this.style.transform='scale(1.05)';" 
    onmouseout="this.style.backgroundColor='darkcyan'; this.style.transform='scale(1)';">
    <a href="admin.php" style="color: white; text-decoration: none; font-size: 14px; font-weight: bold; display: inline-block; width: 100%; height: 100%; line-height: 40px; text-align: center;">
       Home
    </a>
    <?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $_SESSION['tname'] = $_POST['tname'];
        $_SESSION['semester'] = $_POST['semester'];
        $_SESSION['change'] = $_POST['change'];
        header('Location: updated_teacher.php');
        exit();
    }
    ?>
</body>
</html>