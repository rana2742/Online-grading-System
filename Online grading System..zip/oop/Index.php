<?php

session_start();
require_once 'Dbconnect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Admin login form handling
    if (isset($_POST["name"]) && isset($_POST["password"]) && isset($_POST["email"]) && isset($_POST["id"])) {
        $name = $_POST["name"];
        $password = $_POST["password"];
        $id = $_POST["id"];
        $email = $_POST["email"];

        // Escape inputs to prevent SQL injection
        $name = mysqli_real_escape_string($conn, $name);
        $password = mysqli_real_escape_string($conn, $password);
        $id = mysqli_real_escape_string($conn, $id);
        $email = mysqli_real_escape_string($conn, $email);

        // SQL query for Admin login
        $sql = "SELECT * FROM admin WHERE name='$name' AND email='$email' AND password='$password' AND id='$id'";
        $result = mysqli_query($conn, $sql);

        // Check if the query was successful
        if (!$result) {
            die("Query failed: " . mysqli_error($conn)); // Show error if query fails
        }

        // Check if the query returned a result
        if (mysqli_num_rows($result) > 0) {
            // Redirect to admin dashboard if credentials match
            header("Location: admin/admin.php");
            exit();
        } else {
            echo "<p style='color: red;'>Invalid login credentials, please try again.</p>";
        }
    }}

    

    if (isset($_POST["tname"]) && isset($_POST["subject"]) && isset($_POST["coursecode"]) && isset($_POST["semester"]) && isset($_POST["id"])) {
        // Get the form inputs and sanitize
        $tname = trim($_POST["tname"]);
        $subject = trim($_POST["subject"]);
        $coursecode = trim($_POST["coursecode"]);
        $semester = trim($_POST["semester"]);
        $id = trim($_POST["id"]);
        
        $_SESSION['semester']=$semester;
        $_SESSION['tname']=$tname;
        $_SESSION['coursecode']=$coursecode;
        $_SESSION['id']=$id;
        $_SESSION['subject']=$subject;

    
        // Escape inputs to prevent SQL injection
        $tname = mysqli_real_escape_string($conn, $tname);
        $subject = mysqli_real_escape_string($conn, $subject);
        $coursecode = mysqli_real_escape_string($conn, $coursecode);
        $semester = mysqli_real_escape_string($conn, $semester);
        $id = mysqli_real_escape_string($conn, $id);
    
        // Prepare the SQL query with placeholders
        $sql = "SELECT * FROM assign_subjects WHERE name=? AND subject=? AND coursecode=? AND id=? AND semester=?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssss", $tname, $subject, $coursecode, $id, $semester);
    
        // Execute the query
        if (!mysqli_stmt_execute($stmt)) {
            echo "<p style='color: red;'>Error executing query: " . mysqli_stmt_error($stmt) . "</p>";
            exit();
        }
    
        // Get the result
        $result = mysqli_stmt_get_result($stmt);
    
        // Check if the query returned a result
        if (mysqli_num_rows($result) > 0) {
            // Valid semester
            if ($semester == "2023-27") {
                $session_table = "session23";
            } elseif ($semester == "2022-26") {
                $session_table = "session22";
            } elseif ($semester == "2021-25") {
                $session_table = "session21";
            } elseif ($semester == "2024-28") {
                $session_table = "session24";
            } else {
                echo "<p style='color: red;'>Invalid semester selected.</p>";
                exit();
            }
    
            // Check if the selected session table exists
            $check_table_query = "SHOW TABLES LIKE '$session_table'";
            $check_table_result = mysqli_query($conn, $check_table_query);
    
            if (mysqli_num_rows($check_table_result) > 0) {
                // Table exists, redirect to the addmarks.php page
                header("Location: /oop/teacher/teacher.php?session_table=$session_table");
                exit();
            } else {
                echo "<p style='color: red;'>Assigned session table not found in the database.</p>";
            }
        } else {
            echo "<p style='color: red;'>Invalid login credentials, please try again.</p>";
        }
    }
    ?>
    
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="style.css">
        <title>Login Page</title>
    </head>
    <body>
        <header>
            <img src="pics/images (1).jpeg" alt="Computer Engineering class" width="15%" height="100%">
            <h2>Department of Computer Engineering BZU</h2>
        </header>
    
        <section>
            <div class="background-container">
                <img class="pic_changer" src="pics/book-6957870_1920.jpg" alt="Image 2">
                <img class="pic_changer" src="pics/man-2562325_1920.jpg" alt="Image 3">
                <img class="pic_changer" src="pics/images (9).jpeg" alt="Image 4">
                <img class="pic_changer" src="pics/images (3).jpeg" alt="Image 3">
                <img class="pic_changer" src="pics/university-105709_1920.jpg" alt="Image 4">
                <img class="pic_changer" src="pics/Pexels.jpg" alt="Image 5">
            </div>
            
            <div class="overlay">
                <div class="content">
                    <div class="left">
                        <h3>Teacher Portal</h3>
                        <form action="index.php" method="POST">
                            <label for="tname">Name:</label>
                            <input type="text" name="tname" required placeholder="Enter Your name" style="margin-left:70px ;"><br><br>
    
                            <label for="subject">Subject:</label>
                            <input type="text" name="subject" required placeholder="Enter Subject Name" style="margin-left: 70px;"><br><br>
    
                            <label for="coursecode">Course Code:</label>
                            <input type="text" name="coursecode" required placeholder="Enter course code" style="margin-left: 15px;"><br><br>
    
                            <label for="semester">Enter Semester:</label>
                            <input type="text" name="semester" required placeholder="Enter Semester"><br><br>
    
                            <label for="id">Enter Your ID:</label>
                            <input type="text" name="id" required placeholder="Enter Your ID" style="margin-left:10px ;"><br><br>
    
                            <button type="submit">LOG IN</button> 
                        </form> 
             
                </div>

                <!-- Admin Portal Form -->
                <div class="right">
                    <h3>Admin Portal</h3>
                    <form method="POST" action="index.php">
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" required placeholder="Enter Your name" style="margin-left:40px ;"><br><br>

                        <label for="email">Email:</label>
                        <input type="email" id="email" name="email" required placeholder="Enter your Email" style="margin-left:40px ;"><br><br>

                        <label for="password">Password:</label>
                        <input type="password" id="password" name="password" required placeholder="Enter your password" style="margin-left:20px ;" ><br><br>

                        <label for="id">Enter Your ID:</label>
                        <input type="text" id="id" name="id" required placeholder="Enter your ID"><br><br>

                        <button type="submit">LOG IN</button>
                    </form>
                </div>
            </div>

            <h1><a href="checkresult.php">Check your Result here</a></h1>
        </div>

        
    </section>

    <script>
        // Automatic Slideshow - change image every 3 seconds
        var myIndex = 0;
        photo_changer();

        function photo_changer() {
            var i;
            var x = document.getElementsByClassName("pic_changer");
            for (i = 0; i < x.length; i++) {
                x[i].style.display = "none";
            }
            myIndex++;
            if (myIndex > x.length) { myIndex = 1 }
            x[myIndex - 1].style.display = "block";
            setTimeout(photo_changer, 3000); // Change image every 3 seconds
        }
    </script>
</body>
</html>


 
 

 
