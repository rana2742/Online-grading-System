<?php 
require_once '../Dbconnect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data and sanitize it to prevent SQL injection
    $subject = trim($_POST["subject"]);
    $semester = trim($_POST["semester"]);

    // Ensure that there are no unexpected spaces
    $subject = mysqli_real_escape_string($conn, $subject);
    $semester = mysqli_real_escape_string($conn, $semester);

    // Redirect to the 'showrecord.php' page with the search parameters passed via POST
    header("Location: showrecord.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Allocate Subject</title>
    <link rel="stylesheet" href="allocated.css">
</head>
<body>
    <header>
        <img src="../pics/images (1).jpeg" alt="Computer Engineering">
        <h1>Department of Computer Engineering BZU Multan</h1>
    </header> 

    <div class="overlay">
        <div class="content">
            <!-- Form to submit data to showrecord.php using POST method -->
            <form action="showrecord.php" method="POST">
                <input type="text" placeholder="Enter Subject name" name="subject" required>
                <br><br>
                <input type="text" placeholder="Enter semester" name="semester" required><br> <br>
                <input type="submit" id="submitBtn" value="Search">
            </form>
        </div> <br> <br> <br> 
        <div class="move" style="text-align: center;">
        <button 
    style="width: 70px; height: 40px; border-radius: 5px; background-color: darkcyan; margin-left: 20px; border: none; cursor: pointer; transition: background-color 0.3s, transform 0.2s;" 
    onmouseover="this.style.backgroundColor='teal'; this.style.transform='scale(1.05)';" 
    onmouseout="this.style.backgroundColor='darkcyan'; this.style.transform='scale(1)';">
    <a href="../Index.php" style="color: white; text-decoration: none; font-size: 14px; font-weight: bold; display: inline-block; width: 100%; height: 100%; line-height: 40px; text-align: center;">
        Log Out
    </a>
</button>
<button 
    style="width: 70px; height: 40px; border-radius: 5px; background-color: darkcyan; margin-left: 20px; border: none; cursor: pointer; transition: background-color 0.3s, transform 0.2s;" 
    onmouseover="this.style.backgroundColor='teal'; this.style.transform='scale(1.05)';" 
    onmouseout="this.style.backgroundColor='darkcyan'; this.style.transform='scale(1)';">
    <a href="admin.php" style="color: white; text-decoration: none; font-size: 14px; font-weight: bold; display: inline-block; width: 100%; height: 100%; line-height: 40px; text-align: center;">
       Home
    </a>
</button>
</div>

    </div>
</body> 
</html>
