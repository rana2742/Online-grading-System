<?php
 require_once '../Dbconnect.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get the form data
    $teacherName = mysqli_real_escape_string($conn, $_POST['name']);
    $courseName = mysqli_real_escape_string($conn, $_POST['course']);
    $courseCode = mysqli_real_escape_string($conn, $_POST['coursecode']);
    $semester = mysqli_real_escape_string($conn, $_POST['semester']);
    $id = mysqli_real_escape_string($conn, $_POST['id']);
    // SQL query to insert the data into the table
    $sql = " INSERT INTO assign_subjects (`name`, `subject`, `coursecode`, `semester`,`id`) 
            VALUES ('$teacherName', '$courseName', '$courseCode', '$semester','$id')";

    if ($conn->query($sql) === TRUE) {

        echo "Record successfully inserted!";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;

    }

    // Close connection
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>update student record</title>
    <link rel="stylesheet" href="assign.css">
</head>

  
<body>
    <header>
        <img src="../pics/images (1).jpeg" alt="Computer Engneering  " >
            <h1>Department of Computer Engineering BZU Multan </h1>
        
    </header> 
    <div class="overlay">
    <div class="content">
  <form method="POST" action="assign.php">
    <label for="Teacher name">Enter Teacher Name</label><br>
    <input type="text" name="name" required><br><br>
  
    <label for="Subject name">Enter Course Name</label><br>
    <input type="text" name="course" required><br><br>
  
    <label for="Subject code">Enter Course Code</label><br>
    <input type="text" name="coursecode" required><br><br>

    <label for="Select semester">Select semester</label><br>
    <select name="semester" id="sessionSelect" required>
      <option value="2021-25">Session: 2021-25</option>
      <option value="2022-26">Session: 2022-26</option>
      <option value="2023-27" selected>Session: 2023-27</option>
      <option value="2024-28">Session: 2024-28</option>
    </select>
    <br><br>
  
    <label for=" Security id"> Give id to teacher:</label><br>
    <input type="text" name="id" required><br><br>
    <!-- Submit button -->
    <input type="submit" id="submitBtn" value="Submit">
  </form>
  
</div><div class="new">
   <button><a href="Admin.php">HOME</a></button> 
    <button ><a href="upteacher.php">Update Teacher</a></button> 
   <button ><a href="../Index.php">Log Out</a></button> 
</div>
</body>
</html>