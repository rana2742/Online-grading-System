<?php
session_start();
require_once('../Dbconnect.php');

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $student = trim($_POST["student"]);
    $subject = trim($_POST["subject"]);
    $semester = trim($_POST["semester"]);
    $roll_no = trim($_POST["roll_no"]);

    // Save to session
    $_SESSION['semester'] = $semester;
    $_SESSION['student'] = $student;
    $_SESSION['roll_no'] = $roll_no;
    $_SESSION['subject'] = $subject;

    // Sanitize data
    $student = mysqli_real_escape_string($conn, $student);
    $subject = mysqli_real_escape_string($conn, $subject);
    $semester = mysqli_real_escape_string($conn, $semester);
    $roll_no = mysqli_real_escape_string($conn, $roll_no);

    // Prepare SQL query based on semester
    if ($semester =='2023-27') {
        $sql = "SELECT * FROM session23 WHERE subject='$subject' AND roll_no='$roll_no'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            // Table exists, redirect to the updated.php page
            header("Location: updated.php");
            exit();
        } else {
            echo "<p style='color: red;'>Assigned session table not found in the database.</p>";
        }
    } elseif ($semester == '2022-26') {
        $sql = "SELECT * FROM session22 WHERE subject='$subject' AND roll_no='$roll_no'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            // Handle results for this semester
        } else {
            echo "<p style='color: red;'>Assigned session table not found in the database for semester 2022-26.</p>";
        }
    } elseif ($semester == '2021-25') {
        $sql = "SELECT * FROM session21 WHERE subject='$subject' AND roll_no='$roll_no'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            // Handle results for this semester
        } else {
            echo "<p style='color: red;'>Assigned session table not found in the database for semester 2021-25.</p>";
        }
    } elseif ($semester == '2024-28') {
        $sql = "SELECT * FROM session24 WHERE subject='$subject' AND roll_no='$roll_no'";
        $result = mysqli_query($conn, $sql);
        if (mysqli_num_rows($result) > 0) {
            // Handle results for this semester
        } else {
            echo "<p style='color: red;'>Assigned session table not found in the database for semester 2024-28.</p>";
        }
    } else {
        echo "<p style='color: red;'>Invalid semester.</p>";
    }

    // Close the database connection
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Allocate Subject</title>
    <link rel="stylesheet" href="allocated.css">
</head>
<body>
    <header>
        <img src="../pics/images (1).jpeg" alt="Computer Engineering">
        <h1>Department of Computer Engineering BZU Multan</h1>
    </header> 

    <div class="overlay">
        <div class="content">
            <!-- Form to submit data to showrecord.php using POST method -->
            <form action="" method="POST">
                <input type="text" placeholder="Enter Student name" name="student" required><br><br>
                <input type="text" placeholder="Enter semester" name="semester" required><br><br>
                <input type="text" placeholder="Enter Your Roll No." name="roll_no" required><br><br>
                <input type="text" placeholder="Enter course name" name="subject" required><br><br>
                <input type="submit" id="submitBtn" value="Search">
            </form>
        </div>
    </div>
</body> 
</html>
