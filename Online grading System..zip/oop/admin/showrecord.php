<?php
require_once '../Dbconnect.php';

// Check if the form is submitted and the required parameters are set
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $subject = mysqli_real_escape_string($conn, trim($_POST['subject']));
    $semester = mysqli_real_escape_string($conn, trim($_POST['semester']));
    
    // Construct the SQL query to fetch the record
    $sql = "SELECT * FROM assign_subjects WHERE LOWER(subject) = LOWER('$subject') AND LOWER(semester) = LOWER('$semester')";
    $result = mysqli_query($conn, $sql);

    // Check for query errors
    if (!$result) {
        echo "Error in query: " . mysqli_error($conn);
    }

    // Check if any records are found
    if (mysqli_num_rows($result) > 0) {
        // Fetch the record
        $row = mysqli_fetch_assoc($result);
    } else {
        $row = null; // No record found
    }
} else {
    $row = null; // If no parameters were passed, set row as null
}

mysqli_close($conn); // Close the database connection
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Show Record</title>
    <link rel="stylesheet" href="showrecord.css">
</head>
<body>

    <header>
        <img src="../pics/images (1).jpeg" alt="Computer Engineering">
        <h1>Department of Computer Engineering BZU Multan</h1>
    </header>

    <div class="container">
        <h2>Search Result</h2>

        <?php if ($row): ?>
        <table>
            <thead>
                <tr>
                    <th>Sr. No</th>
                    <th>Name</th>
                    <th>Subject</th>
                    <th>Course Code</th>
                    <th>Semester</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td> <!-- In this case, we are displaying one record, so Sr. No is 1 -->
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['subject']); ?></td>
                    <td><?php echo htmlspecialchars($row['coursecode']); ?></td>
                    <td><?php echo htmlspecialchars($row['semester']); ?></td>
                </tr>
            </tbody>
        </table>
        <?php else: ?>
        <p>No records found for the specified subject and semester.</p>
        <?php endif; ?>
    </div>
<div class="new">
   <button><a href="Admin.php">HOME</a></button> 
   <button><a href="assign.php">Assign Subjects</a></button> 
   <button><a href="update.php">Update Student Record</a></button> 
   <button><a href="../Index.php">Log Out</a></button> 
</div>


              
</body>
</html>
