<?php 
session_start();
require_once('Dbconnect.php'); 

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_SESSION['student'] = $_POST['studentn'];
    $_SESSION['semester'] = $_POST['semester'];
    $_SESSION['roll_no'] = $_POST['roll_no'];
    $_SESSION['subject'] = $_POST['subject'];
    header('Location: result.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check Your Result</title>
    <link rel="stylesheet" href="result.css">
</head>
<body>
    <header>
        <img src="../oop/pics/images (1).jpeg" alt="Computer Engineering">
        <h1>Department of Computer Engineering BZU Multan</h1>
    </header>
    <form action="checkresult.php" METHOD="POST">
        <input type="text" placeholder="Enter your name" name="studentn" required><br><br>
        <input type="text" placeholder="Enter semester" name="semester" required><br><br>
        <input type="text" placeholder="Enter Your Roll No." name="roll_no" required><br><br>
        <input type="text" placeholder="Enter course name" name="subject" required><br><br>
        <input type="submit" id="submitBtn" value="Search">
    </form>
    <button 
    style="width: 70px; height: 40px; border-radius: 5px; background-color: darkcyan; margin-left: 20px; border: none; cursor: pointer; transition: background-color 0.3s, transform 0.2s;" 
    onmouseover="this.style.backgroundColor='teal'; this.style.transform='scale(1.05)';" 
    onmouseout="this.style.backgroundColor='darkcyan'; this.style.transform='scale(1)';">
    <a href="Index.php" style="color: white; text-decoration: none; font-size: 14px; font-weight: bold; display: inline-block; width: 100%; height: 100%; line-height: 40px; text-align: center;">
        Home
    </a>
</button>
 
</body>
</html>