<?php
session_start();
echo "<div style='text-align: center; font-size: 24px; color: #4CAF50; font-family: Arial, sans-serif; padding: 20px; background-color: #f0f8ff; border-radius: 10px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);'>";
echo "Welcome, <span style='font-weight: bold; color: #2c3e50;'>" . htmlspecialchars($_SESSION['tname']) . "</span>!";
echo "</div>";
  if (isset($_SESSION['semester'])) {
    // Check if the semester is '2023-27'
    if ($_SESSION['semester'] == '2023-27') {
        // If the condition is met, set the link to 'session23.php'
        $link = 'session23.php';
    } 
    // Check if the semester is '2022-26'
    elseif ($_SESSION['semester'] == '2022-26') {
        // If the condition is met, set the link to 'session22.php'
        $link = 'session22.php';
    }
    elseif ($_SESSION['semester'] == '2021-25') {
      // If the condition is met, set the link to 'session22.php'
      $link = 'session25.php';
  }elseif ($_SESSION['semester'] == '2024-28') {
    // If the condition is met, set the link to 'session22.php'
    $link = 'session24.php';
}
  } 
else {
    // If 'semester' is not set in the session, show an error message
    echo "Error in getting the link!";
}
?>


<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher's portal</title>
    <link rel="stylesheet" href="teacher.css">
  </head>
  
  
  <body>
    <div class="containeer">
    <nav>
        <div class="left">Department of Computer Engineering</div>
        <div class="sideicons">
          <ul>
         
              <li><a href="<?php echo $link; ?>">Add Student Marks</a> </li>
  
            <li><a href="../mycv.html">ABOUT US</a></li>
            <li><button style="width: 70px; height:40px;border-radius:5px ;background-color:darkcyan;margin-left:20px"><a href="../Index.php">Log Out</a></button></li>
            
          </ul>
        </div>
    </nav>
 
<h1>Key Features:</h1>
<p> "Welcome to the Teacher Portal, where you can easily manage student grades and keep track of academic progress."</p>
<h1>Our goals:</h1>
<p>Our platform provides an easy-to-use interface for teachers to efficiently manage and update student records. With just a few clicks, educators can add, edit, and track essential student information such as grades, attendance, and performance over time. Whether it’s updating class notes, monitoring progress, or managing communication with parents, our system streamlines administrative tasks so teachers can focus more on teaching. Secure, user-friendly, and customizable, our platform ensures that every student’s data is organized and accessible at all times, helping create a more effective and transparent learning environment.</p>
<h1> Benifits For Teachers:</h1>
<p>Highlight how the platform saves time, improves efficiency, and helps in providing more personalized learning experiences. You could mention features like easy access to student data, automatic updates, and streamlined communication with parents.

</p>

  </div>
  <footer>
    Department of computer Engineering BZU Multan®|©All rights reserved
  </footer>

  </body>
</html>



